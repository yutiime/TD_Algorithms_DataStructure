int linear_search(int *arr, int n, int target);
int jump_search(int *arr, int n, int target);
int binary_search(int *arr, int n, int target);