#include <stdbool.h>

bool is_sorted_nondecreasing(int *arr, int n);
int min_int(int a, int b);