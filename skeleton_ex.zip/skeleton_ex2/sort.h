void selection_sort(int *arr, int n);
void insertion_sort(int *arr, int n);
void bubble_sort(int *arr, int n);
void merge_sort(int *arr, int n);
void quick_sort(int *arr, int n);