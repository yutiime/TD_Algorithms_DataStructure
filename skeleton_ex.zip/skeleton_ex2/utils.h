#include <stdbool.h>

void swap_int(int *a, int *b);
bool is_sorted_nondecreasing(int *arr, int n);
void copy_array(int *src, int *dst, int n);