#include "utils.h"

void swap_int(int *a, int *b)
{
    // swap two elements
}

bool is_sorted_nondecreasing(int *arr, int n)
{
    // check if array is sorted, if yes return true
    // if not return false
}

void copy_array(int *src, int *dst, int n)
{
    // copy array elements src into dst
}