#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "sort.h"
#include "utils.h"

int main(void)
{
    // implement main here
    // create array example using malloc
    // use sorting algorithms and compare runtime
    return 0;
}
